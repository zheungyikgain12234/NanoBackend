"""
byoa_adk/response_validator.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Validates the TaskResult returned by the agent's run() method
before it is serialised and sent back to the platform.

Used automatically by server.py — agent developers never call this directly.

Checks:
  1. TaskResult has required fields (task_id, status, outputs)
  2. status is a valid TaskStatus enum value
  3. outputs contains all keys declared in the agent's output_schema
  4. output values match declared types (string, integer, number, boolean)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from .schema import TaskResult, TaskStatus

# Map JSON Schema type strings to Python types
_TYPE_MAP: dict[str, type] = {
    'string':  str,
    'integer': int,
    'number':  (int, float),
    'boolean': bool,
    'object':  dict,
    'array':   list,
}


@dataclass
class ResponseValidationResult:
    valid: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def fail(self, msg: str):
        self.valid = False
        self.errors.append(msg)

    def warn(self, msg: str):
        self.warnings.append(msg)


def validate_task_result(
    result: TaskResult,
    output_schema: dict,
) -> ResponseValidationResult:
    """
    Validate a TaskResult against the agent's declared output_schema.

    Parameters
    ----------
    result        : The TaskResult returned by agent.run().
    output_schema : The output_schema from AgentManifest
                    e.g. {'type': 'object', 'properties': {
                              'summary':  {'type': 'string'},
                              'fallback_reason': {'type': 'string', 'nullable': True},
                              'truncated': {'type': 'boolean', 'required': False},
                         }}

                    Per-property flags (both optional, both default False):
                      nullable: True  -> a present value of None passes, regardless of type
                      required: False -> the key may be omitted from outputs entirely
                    These exist because some agents legitimately return None or omit
                    a key on some branches (e.g. no-match vs. match paths in a
                    retrieval agent) -- without them every such branch would fail
                    contract validation that only the SUCCESS/full-match path meant
                    to satisfy.

    Returns
    -------
    ResponseValidationResult with valid=True or errors list.
    """
    r = ResponseValidationResult()

    # Only validate outputs on SUCCESS — FAILURE/DEGRADED may have empty outputs
    if result.status != TaskStatus.SUCCESS:
        return r

    outputs = result.outputs or {}
    properties = output_schema.get('properties', {})

    if not properties:
        # No properties declared — nothing to validate
        return r

    # Check all declared properties are present and correct type
    for key, defn in properties.items():
        is_required = defn.get('required', True)

        if key not in outputs:
            if is_required:
                r.fail(f'outputs missing declared key: "{key}"')
            continue

        actual_value = outputs[key]

        if actual_value is None:
            if defn.get('nullable', False):
                continue
            r.fail(f'outputs["{key}"] is None but property is not marked nullable')
            continue

        expected_type_str = defn.get('type')
        if not expected_type_str:
            r.warn(f'output_schema.{key} has no "type" — skipping type check')
            continue

        expected_type = _TYPE_MAP.get(expected_type_str)
        if expected_type is None:
            r.warn(f'Unknown type "{expected_type_str}" for key "{key}" — skipping')
            continue

        if not isinstance(actual_value, expected_type):
            r.fail(
                f'outputs["{key}"] expected {expected_type_str}, '
                f'got {type(actual_value).__name__}: {repr(actual_value)[:60]}'
            )

    # Warn about undeclared keys (not an error — agent may return extra info)
    for key in outputs:
        if key not in properties:
            r.warn(f'outputs["{key}"] not declared in output_schema (extra field)')

    return r
